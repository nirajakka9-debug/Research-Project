Place your face video files (e.g., .mp4, .avi, .mov, .mkv, .webm) in this folder.

Example usage:
  python main.py --video videos/my_video.mp4 --output outputs/results.json
