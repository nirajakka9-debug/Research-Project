This folder is for storing exported JSON results.

Example usage:
  python main.py --video videos/my_video.mp4 --output outputs/my_video_results.json
